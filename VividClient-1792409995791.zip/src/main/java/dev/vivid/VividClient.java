package dev.vivid;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class VividClient implements ClientModInitializer {
    public static ModuleManager MODULES;
    public static int accentColor = 0xFFB44CFF;
    public static KeyBinding GUI_KEY;
    private static long guiOpenedAt;

    @Override
    public void onInitializeClient() {
        MODULES = Modules.create();
        VividHud.initialize();
        VividConfig.load();
        VividFeatures.initialize();
        GUI_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vivid.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.vivid.controls"));
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen && System.currentTimeMillis() - guiOpenedAt > 500) {
                client.setScreen(new VividTitleScreen());
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(VividClient::onTick);
    }

    private static void onTick(MinecraftClient client) {
        while (GUI_KEY.wasPressed()) {
            if (client.currentScreen instanceof ClickGuiScreen) {
                client.setScreen(null);
            } else if (client.currentScreen == null) {
                guiOpenedAt = System.currentTimeMillis();
                client.setScreen(new ClickGuiScreen());
            }
        }
    }
}