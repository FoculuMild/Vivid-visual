package dev.vivid;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

final class VividFeatures {
    private static KeyBinding zoomKey;
    private static Boolean originalViewBobbing;
    private static Integer originalFov;
    private static Double originalGamma;
    private static Double originalChatOpacity;
    private static boolean wasSneaking;
    private static double previousX;
    private static double previousY;
    private static double previousZ;
    private static boolean hasPreviousPosition;
    private static boolean chamsApplied;
    private static final Map<UUID, Boolean> ORIGINAL_GLOW = new HashMap<>();

    private VividFeatures() {
    }

    static void initialize() {
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vivid.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C,
                "category.vivid.controls"));
        ClientTickEvents.END_CLIENT_TICK.register(VividFeatures::tick);
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            restoreViewBobbing(client);
            restoreZoom(client);
            clearChams(client);
            hasPreviousPosition = false;
            wasSneaking = false;
            return;
        }

        if (enabled("AutoRespawn") && client.player.isDead()) {
            client.player.requestRespawn();
        }
        updateViewBobbing(client);
        updateZoom(client);
        updateClientOptions(client);
        updateAutoTool(client);
        updateCosmeticParticles(client);
        updateChams(client);
    }

    private static boolean enabled(String name) {
        return VividClient.MODULES.find(name).map(Module::enabled).orElse(false);
    }

    private static void updateViewBobbing(MinecraftClient client) {
        if (enabled("View Bobbing")) {
            if (originalViewBobbing == null) originalViewBobbing = client.options.getBobView().getValue();
            client.options.getBobView().setValue(false);
        } else {
            restoreViewBobbing(client);
        }
    }

    private static void restoreViewBobbing(MinecraftClient client) {
        if (originalViewBobbing != null) {
            client.options.getBobView().setValue(originalViewBobbing);
            originalViewBobbing = null;
        }
    }

    private static void updateZoom(MinecraftClient client) {
        boolean zooming = enabled("Zoom") && zoomKey.isPressed() && client.currentScreen == null;
        if (zooming && originalFov == null) originalFov = client.options.getFov().getValue();
        if (originalFov == null) return;

        int target = zooming ? Math.max(15, (int) (originalFov * 0.3)) : originalFov;
        int current = client.options.getFov().getValue();
        int next = current + Math.max(1, Math.abs(target - current) / 4) * Integer.signum(target - current);
        if (Math.abs(target - current) <= 1) next = target;
        client.options.getFov().setValue(next);
        if (!zooming && next == originalFov) originalFov = null;
    }

    private static void restoreZoom(MinecraftClient client) {
        if (originalFov != null) {
            client.options.getFov().setValue(originalFov);
            originalFov = null;
        }
    }

    private static void updateClientOptions(MinecraftClient client) {
        if (enabled("Fullbright")) {
            if (originalGamma == null) originalGamma = client.options.getGamma().getValue();
            client.options.getGamma().setValue(1.0);
        } else if (originalGamma != null) {
            client.options.getGamma().setValue(originalGamma);
            originalGamma = null;
        }

        if (enabled("Chat Tweaks")) {
            if (originalChatOpacity == null) originalChatOpacity = client.options.getChatBackgroundOpacity().getValue();
            client.options.getChatBackgroundOpacity().setValue(0.0);
        } else if (originalChatOpacity != null) {
            client.options.getChatBackgroundOpacity().setValue(originalChatOpacity);
            originalChatOpacity = null;
        }
    }

    private static void updateAutoTool(MinecraftClient client) {
        if (!enabled("AutoTool") || !client.options.attackKey.isPressed()
                || !(client.crosshairTarget instanceof BlockHitResult hit)
                || hit.getType() != HitResult.Type.BLOCK) return;

        var state = client.world.getBlockState(hit.getBlockPos());
        var inventory = client.player.getInventory();
        int bestSlot = inventory.selectedSlot;
        float bestSpeed = inventory.getStack(bestSlot).getMiningSpeedMultiplier(state);
        for (int slot = 0; slot < 9; slot++) {
            float speed = inventory.getStack(slot).getMiningSpeedMultiplier(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = slot;
            }
        }
        inventory.selectedSlot = bestSlot;
    }

    private static void updateCosmeticParticles(MinecraftClient client) {
        PlayerEntity player = client.player;
        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();

        if (enabled("Trail") && hasPreviousPosition
                && player.squaredDistanceTo(previousX, previousY, previousZ) > 0.0025) {
            client.world.addParticle(ParticleTypes.END_ROD, x, y + 0.15, z, 0.0, 0.025, 0.0);
        }

        if (enabled("China Hat") && player.age % 3 == 0) {
            double radius = 0.58;
            double hatY = y + player.getHeight() + 0.18;
            for (int point = 0; point < 12; point++) {
                double angle = (Math.PI * 2.0 * point / 12.0) + player.age * 0.025;
                client.world.addParticle(ParticleTypes.END_ROD,
                        x + Math.cos(angle) * radius, hatY, z + Math.sin(angle) * radius,
                        0.0, 0.005, 0.0);
            }
        }

        if (enabled("Target Circle") && player.age % 3 == 0
                && client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() != player) {
            Entity target = hit.getEntity();
            double radius = Math.max(0.45, Math.min(1.2, target.getWidth() * 0.65));
            for (int point = 0; point < 16; point++) {
                double angle = Math.PI * 2.0 * point / 16.0;
                client.world.addParticle(ParticleTypes.END_ROD,
                        target.getX() + Math.cos(angle) * radius, target.getY() + 0.08,
                        target.getZ() + Math.sin(angle) * radius, 0.0, 0.0, 0.0);
            }
        }

        boolean sneaking = player.isSneaking();
        if (enabled("Shift Tap") && sneaking && !wasSneaking) {
            for (int i = 0; i < 8; i++) {
                double angle = Math.PI * 2.0 * i / 8.0;
                client.world.addParticle(ParticleTypes.CLOUD, x, y + 0.1, z,
                        Math.cos(angle) * 0.06, 0.02, Math.sin(angle) * 0.06);
            }
        }
        wasSneaking = sneaking;
        previousX = x;
        previousY = y;
        previousZ = z;
        hasPreviousPosition = true;
    }

    private static void updateChams(MinecraftClient client) {
        if (!enabled("Chams")) {
            clearChams(client);
            return;
        }
        chamsApplied = true;
        for (PlayerEntity player : client.world.getPlayers()) {
            if (player == client.player) continue;
            ORIGINAL_GLOW.putIfAbsent(player.getUuid(), player.isGlowing());
            player.setGlowing(true);
        }
    }

    private static void clearChams(MinecraftClient client) {
        if (!chamsApplied && ORIGINAL_GLOW.isEmpty()) return;
        if (client.world != null) {
            for (PlayerEntity player : client.world.getPlayers()) {
                Boolean wasGlowing = ORIGINAL_GLOW.get(player.getUuid());
                if (wasGlowing != null) player.setGlowing(wasGlowing);
            }
        }
        ORIGINAL_GLOW.clear();
        chamsApplied = false;
    }
}