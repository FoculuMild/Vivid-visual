package dev.vivid;

public final class Modules {
    private Modules() {
    }

    public static ModuleManager create() {
        ModuleManager manager = new ModuleManager();
        add(manager, ModuleCategory.HUD, true,
                "Watermark", "Vivid branding and FPS",
                "Keystrokes", "Displays movement and mouse keys",
                "TargetHUD", "Displays the entity under the crosshair",
                "Armor HUD", "Displays equipped armor durability",
                "Potion HUD", "Displays active potion effects",
                "CPS", "Displays clicks per second",
                "Coordinates", "Displays player coordinates",
                "Ping Display", "Displays server latency",
                "Scoreboard", "Displays the current scoreboard");
        add(manager, ModuleCategory.VISUALS, false,
                "Custom Sky", "Applies a purple sky tint",
                "Custom Fog", "Adjusts local fog appearance",
                "China Hat", "Cosmetic particle hat above the player",
                "Trail", "Cosmetic particles behind the player",
                "Chams", "Entity highlighting render option",
                "Target Circle", "Displays a circle around the target",
                "View Bobbing", "Controls camera bobbing",
                "Damage Tint", "Adds a damage screen tint",
                "Custom Crosshair", "Draws a custom crosshair",
                "Block Outline", "Customizes block selection outlines",
                "Zoom", "Smooth camera zoom control",
                "Fullbright", "Raises local brightness",
                "Time Changer", "Changes the local time display",
                "Weather Changer", "Changes local weather rendering",
                "Item Physics", "Changes dropped item rotation",
                "Custom Animations", "Customizes first-person swing animation",
                "Shift Tap", "Adds a cosmetic crouch effect",
                "Capes", "Enables client-side cape rendering");
        add(manager, ModuleCategory.UTILITY, false,
                "AutoTool", "Selects a suitable hotbar tool while mining",
                "AutoReconnect", "Reconnects after a disconnect",
                "Chat Tweaks", "Removes the chat background",
                "Inventory Tweaks", "Adjusts inventory background rendering",
                "Item Tooltips", "Enables enhanced item tooltip styling",
                "NoRender", "Hides selected fire and weather overlays",
                "AutoRespawn", "Requests respawn after death");
        return manager;
    }

    private static void add(ModuleManager manager, ModuleCategory category, boolean enabled, String... values) {
        for (int index = 0; index < values.length; index += 2) {
            String name = values[index];
            String description = values[index + 1];
            manager.register(new Module(name, description, category, enabled));
        }
    }
}