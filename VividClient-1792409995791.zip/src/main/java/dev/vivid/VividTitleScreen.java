package dev.vivid;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public final class VividTitleScreen extends Screen {
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Settings", "Alt Manager"};
    private static final String[] ICONS = {"S", "M", "⚙", "A"};
    private float hoverAlpha;

    public VividTitleScreen() {
        super(Text.literal("Vivid"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        context.fillGradient(0, 0, width, height, 0xFF071127, 0xFF281044);
        ParticleField.draw(context, width, height, now, 0xFFD9B8FF);
        context.drawCenteredTextWithShadow(textRenderer, "Vivid", width / 2, height / 3 - 30, 0xFFFFFFFF);
        int centerX = width / 2;
        int centerY = height / 2 + 18;
        int spacing = 78;
        for (int i = 0; i < LABELS.length; i++) {
            int x = centerX + (i - 1) * spacing;
            int y = centerY;
            boolean hovered = Math.hypot(mouseX - x, mouseY - y) <= 25;
            if (hovered) hoverAlpha = Math.min(1.0f, hoverAlpha + delta * 0.12f);
            else hoverAlpha = Math.max(0.28f, hoverAlpha - delta * 0.08f);
            int alpha = (int) (90 + hoverAlpha * 165);
            int circle = (alpha << 24) | (VividClient.accentColor & 0x00FFFFFF);
            drawCircle(context, x, y, 23, circle);
            context.drawCenteredTextWithShadow(textRenderer, ICONS[i], x, y - 4, 0xFFFFFFFF);
            context.drawCenteredTextWithShadow(textRenderer, LABELS[i], x, y + 34, 0xFFE9E2F2);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    private static void drawCircle(DrawContext context, int x, int y, int radius, int color) {
        for (int row = -radius; row <= radius; row++) {
            int halfWidth = (int) Math.sqrt(radius * radius - row * row);
            context.fill(x - halfWidth, y + row, x + halfWidth + 1, y + row + 1, color);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int centerX = width / 2;
        int centerY = height / 2 + 18;
        int spacing = 78;
        for (int i = 0; i < LABELS.length; i++) {
            int x = centerX + (i - 1) * spacing;
            if (Math.hypot(mouseX - x, mouseY - centerY) > 25) continue;
            switch (i) {
                case 0 -> client.setScreen(new SelectWorldScreen(this));
                case 1 -> client.setScreen(new MultiplayerScreen(this));
                case 2 -> client.setScreen(new OptionsScreen(this, client.options));
                case 3 -> client.setScreen(new AltManagerScreen(this));
                default -> { }
            }
            return true;
        }
        return true;
    }

    @Override
    public void close() {
        client.setScreen(null);
    }
}