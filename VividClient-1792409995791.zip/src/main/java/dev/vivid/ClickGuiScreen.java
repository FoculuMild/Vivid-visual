package dev.vivid;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class ClickGuiScreen extends Screen {
    private ModuleCategory category = ModuleCategory.VISUALS;

    public ClickGuiScreen() {
        super(Text.literal("Vivid Click GUI"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, width, height, 0xFF9900FF, 0xFF000000);
        ParticleField.draw(context, width, height, System.currentTimeMillis(), 0xFFE6C8FF);
        int left = width / 2 - 190;
        int top = height / 2 - 150;
        context.fill(left, top, left + 380, top + 300, 0xB9100E18);
        context.fill(left, top, left + 380, top + 28, 0xDD171321);
        context.drawTextWithShadow(textRenderer, "VIVID  /  " + category.title(), left + 10, top + 9, 0xFFFFFFFF);
        int categoryX = left + 12;
        int categoryY = top + 42;
        for (ModuleCategory item : ModuleCategory.values()) {
            int color = item == category ? VividClient.accentColor : 0xFFB8B2C3;
            context.drawTextWithShadow(textRenderer, item.title(), categoryX, categoryY, color);
            categoryX += textRenderer.getWidth(item.title()) + 20;
        }
        var modules = VividClient.MODULES.inCategory(category);
        for (int index = 0; index < modules.size(); index++) {
            Module module = modules.get(index);
            int column = index / 9;
            int row = index % 9;
            int itemX = left + 10 + column * 180;
            int rowY = top + 62 + row * 23;
            boolean hovered = mouseX >= itemX && mouseX <= itemX + 174 && mouseY >= rowY - 4 && mouseY < rowY + 18;
            if (hovered) context.fill(itemX, rowY - 5, itemX + 174, rowY + 17, 0x443FFFFFFF);
            context.drawTextWithShadow(textRenderer, module.name(), itemX + 5, rowY, 0xFFF4F1F8);
            String state = module.enabled() ? "ON" : "OFF";
            int stateColor = module.enabled() ? VividClient.accentColor : 0xFF817B8D;
            context.drawTextWithShadow(textRenderer, state, itemX + 145, rowY, stateColor);
        }
        int colorY = top + 274;
        context.drawTextWithShadow(textRenderer, "Accent color", left + 12, colorY, 0xFFE8E2EF);
        context.fill(left + 105, colorY - 2, left + 133, colorY + 11, VividClient.accentColor);
        context.drawTextWithShadow(textRenderer, "Click swatch to cycle", left + 143, colorY, 0xFFB8B2C3);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int left = width / 2 - 190;
        int top = height / 2 - 150;
        int categoryX = left + 12;
        for (ModuleCategory item : ModuleCategory.values()) {
            int labelWidth = textRenderer.getWidth(item.title());
            if (mouseY >= top + 35 && mouseY <= top + 58 && mouseX >= categoryX - 3 && mouseX <= categoryX + labelWidth + 4) {
                category = item;
                return true;
            }
            categoryX += labelWidth + 20;
        }
        var modules = VividClient.MODULES.inCategory(category);
        for (int index = 0; index < modules.size(); index++) {
            int column = index / 9;
            int row = index % 9;
            int itemX = left + 10 + column * 180;
            int rowY = top + 62 + row * 23;
            if (mouseX >= itemX && mouseX <= itemX + 174 && mouseY >= rowY - 5 && mouseY < rowY + 18) {
                modules.get(index).toggle();
                return true;
            }
        }
        if (mouseX >= left + 100 && mouseX <= left + 140 && mouseY >= top + 267 && mouseY <= top + 290) {
            int[] colors = {0xFFB44CFF, 0xFF4CC9FF, 0xFFFF5C8A, 0xFF70E090, 0xFFFFC857};
            int current = 0;
            for (int i = 0; i < colors.length; i++) if (colors[i] == VividClient.accentColor) current = i;
            VividClient.accentColor = colors[(current + 1) % colors.length];
            VividConfig.save();
            return true;
        }
        return true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}