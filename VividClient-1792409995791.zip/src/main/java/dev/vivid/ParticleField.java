package dev.vivid;

import net.minecraft.client.gui.DrawContext;

public final class ParticleField {
    private ParticleField() {
    }

    public static void draw(DrawContext context, int width, int height, long time, int color) {
        for (int i = 0; i < 52; i++) {
            double phase = i * 2.399963229728653 + time * (0.00012 + (i % 4) * 0.000025);
            double x = Math.floorMod((int) (i * 83L + time / (24 + i % 13)), Math.max(1, width));
            double y = Math.floorMod((int) (i * 47L - time / (31 + i % 17)), Math.max(1, height));
            int radius = i % 9 == 0 ? 2 : 1;
            int alpha = 75 + (int) ((Math.sin(phase) + 1) * 65);
            int particleColor = (color & 0x00FFFFFF) | (alpha << 24);
            for (int row = -radius; row <= radius; row++) {
                int span = radius - Math.abs(row);
                context.fill((int) x - span, (int) y + row, (int) x + span + 1, (int) y + row + 1, particleColor);
            }
        }
    }
}