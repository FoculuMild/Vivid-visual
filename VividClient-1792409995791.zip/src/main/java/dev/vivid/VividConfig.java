package dev.vivid;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class VividConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("vivid.json");

    private VividConfig() {
    }

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(FILE)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null) return;
            if (root.has("accentColor")) VividClient.accentColor = root.get("accentColor").getAsInt();
            JsonObject moduleValues = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
            for (Module module : VividClient.MODULES.all()) {
                JsonElement value = moduleValues.get(module.name());
                if (value != null && value.isJsonPrimitive()) module.setEnabledFromConfig(value.getAsBoolean());
            }
            JsonObject positions = root.has("hudPositions") ? root.getAsJsonObject("hudPositions") : new JsonObject();
            for (String key : positions.keySet()) {
                if (positions.get(key).isJsonObject()) {
                    JsonObject position = positions.getAsJsonObject(key);
                    VividHud.setPosition(key, position.get("x").getAsInt(), position.get("y").getAsInt());
                }
            }
        } catch (Exception exception) {
            System.err.println("[Vivid] Could not load config: " + exception.getMessage());
        }
    }

    public static void save() {
        if (VividClient.MODULES == null) return;
        JsonObject root = new JsonObject();
        root.addProperty("accentColor", VividClient.accentColor);
        JsonObject modules = new JsonObject();
        for (Module module : VividClient.MODULES.all()) modules.addProperty(module.name(), module.enabled());
        root.add("modules", modules);
        JsonObject positions = new JsonObject();
        VividHud.positions().forEach((key, position) -> {
            JsonObject value = new JsonObject();
            value.addProperty("x", position[0]);
            value.addProperty("y", position[1]);
            positions.add(key, value);
        });
        root.add("hudPositions", positions);
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(root, writer);
            }
        } catch (Exception exception) {
            System.err.println("[Vivid] Could not save config: " + exception.getMessage());
        }
    }
}