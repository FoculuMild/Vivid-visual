package dev.vivid;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.session.Session;
import net.minecraft.text.Text;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class AltManagerScreen extends Screen {
    private final Screen parent;
    private final List<String> accounts = new ArrayList<>();
    private TextFieldWidget nickname;
    private int selected = -1;

    public AltManagerScreen(Screen parent) {
        super(Text.literal("Vivid Alt Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        nickname = new TextFieldWidget(textRenderer, width / 2 - 110, height / 2 + 83, 220, 20, Text.literal("Nickname"));
        nickname.setMaxLength(16);
        addSelectableChild(nickname);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, width, height, 0xFF171025, 0xFF07070B);
        ParticleField.draw(context, width, height, System.currentTimeMillis(), 0xFFD3A7FF);
        int left = width / 2 - 150;
        int top = height / 2 - 110;
        context.fill(left, top, left + 300, top + 250, 0xCC100E18);
        context.drawCenteredTextWithShadow(textRenderer, "Alt Manager", width / 2, top + 12, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "Current: " + client.getSession().getUsername(), left + 14, top + 34, 0xFFBEB5CA);
        int rowY = top + 58;
        for (int i = 0; i < accounts.size(); i++) {
            context.fill(left + 12, rowY - 4, left + 288, rowY + 16, i == selected ? 0x663F2858 : 0x332A2633);
            context.drawTextWithShadow(textRenderer, accounts.get(i), left + 20, rowY, 0xFFF1EDF5);
            rowY += 23;
        }
        nickname.render(context, mouseX, mouseY, delta);
        context.fill(left + 14, height / 2 + 111, left + 112, height / 2 + 134, VividClient.accentColor);
        context.drawCenteredTextWithShadow(textRenderer, "Add", left + 63, height / 2 + 118, 0xFFFFFFFF);
        context.fill(left + 188, height / 2 + 111, left + 286, height / 2 + 134, 0xFF4A3A5F);
        context.drawCenteredTextWithShadow(textRenderer, "Use selected", left + 237, height / 2 + 118, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        int left = width / 2 - 150;
        int top = height / 2 - 110;
        int rowY = top + 58;
        for (int i = 0; i < accounts.size(); i++) {
            if (mouseX >= left + 12 && mouseX <= left + 288 && mouseY >= rowY - 4 && mouseY < rowY + 16) {
                selected = i;
                return true;
            }
            rowY += 23;
        }
        if (button == 0 && mouseY >= height / 2 + 108 && mouseY <= height / 2 + 138) {
            if (mouseX >= left + 10 && mouseX <= left + 116) {
                String name = nickname.getText().trim();
                if (name.matches("[A-Za-z0-9_]{3,16}") && !accounts.contains(name)) accounts.add(name);
                nickname.setText("");
                return true;
            }
            if (mouseX >= left + 184 && mouseX <= left + 290 && selected >= 0 && selected < accounts.size()) {
                useAccount(accounts.get(selected));
                return true;
            }
        }
        return true;
    }

    private void useAccount(String username) {
        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
        client.setSession(new Session(username, uuid, "", java.util.Optional.empty(), java.util.Optional.empty(), Session.AccountType.LEGACY));
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}