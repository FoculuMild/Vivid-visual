package dev.vivid;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module module) {
        modules.add(module);
    }

    public List<Module> all() {
        return List.copyOf(modules);
    }

    public List<Module> inCategory(ModuleCategory category) {
        return modules.stream().filter(module -> module.category() == category).toList();
    }

    public Optional<Module> find(String name) {
        return modules.stream().filter(module -> module.name().equalsIgnoreCase(name)).findFirst();
    }
}