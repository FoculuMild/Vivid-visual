package dev.vivid;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.hit.EntityHitResult;

import java.util.LinkedHashMap;
import java.util.Map;

public final class VividHud {
    private static final Map<String, int[]> POSITIONS = new LinkedHashMap<>();
    private static int leftClicks;
    private static int rightClicks;
    private static long clickWindow = System.currentTimeMillis();
    private static boolean wasLeftDown;
    private static boolean wasRightDown;

    private VividHud() {
    }

    public static void initialize() {
        POSITIONS.put("Watermark", new int[]{8, 8});
        POSITIONS.put("Coordinates", new int[]{8, 28});
        POSITIONS.put("Ping Display", new int[]{8, 42});
        POSITIONS.put("Keystrokes", new int[]{8, 62});
        POSITIONS.put("CPS", new int[]{8, 122});
        HudRenderCallback.EVENT.register(VividHud::render);
    }

    public static Map<String, int[]> positions() {
        return POSITIONS;
    }

    public static void setPosition(String name, int x, int y) {
        POSITIONS.put(name, new int[]{x, y});
    }

    private static void render(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;
        sampleClicks(client);
        if (enabled("Watermark")) {
            int[] pos = POSITIONS.get("Watermark");
            text(context, "Vivid  " + client.getCurrentFps() + " FPS", pos[0], pos[1], VividClient.accentColor);
        }
        if (enabled("Coordinates")) {
            int[] pos = POSITIONS.get("Coordinates");
            text(context, String.format("XYZ: %.1f, %.1f, %.1f", client.player.getX(), client.player.getY(), client.player.getZ()), pos[0], pos[1], 0xFFFFFFFF);
        }
        if (enabled("Ping Display") && client.getNetworkHandler() != null) {
            var entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            int[] pos = POSITIONS.get("Ping Display");
            if (entry != null) text(context, "Ping: " + entry.getLatency() + " ms", pos[0], pos[1], 0xFFFFFFFF);
        }
        if (enabled("Keystrokes")) renderKeys(context, client);
        if (enabled("CPS")) {
            int[] pos = POSITIONS.get("CPS");
            text(context, "CPS: " + leftClicks + " | " + rightClicks, pos[0], pos[1], 0xFFFFFFFF);
        }
        if (enabled("Armor HUD")) renderArmor(context, client);
        if (enabled("TargetHUD")) renderTarget(context, client);
        if (enabled("Custom Crosshair")) renderCrosshair(context, client);
        if (enabled("Potion HUD")) renderPotions(context, client);
        if (enabled("Damage Tint") && client.player.hurtTime > 0) renderDamageTint(context, client);
    }

    private static boolean enabled(String name) {
        return VividClient.MODULES.find(name).map(Module::enabled).orElse(false);
    }

    private static void text(DrawContext context, String value, int x, int y, int color) {
        context.fill(x - 3, y - 2, x + MinecraftClient.getInstance().textRenderer.getWidth(value) + 3, y + 11, 0x66080010);
        context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, value, x, y, color);
    }

    private static void renderKeys(DrawContext context, MinecraftClient client) {
        int[] pos = POSITIONS.get("Keystrokes");
        String[] keys = {"W", "A", "S", "D"};
        boolean[] down = {client.options.forwardKey.isPressed(), client.options.leftKey.isPressed(),
                client.options.backKey.isPressed(), client.options.rightKey.isPressed()};
        for (int i = 0; i < keys.length; i++) {
            int x = pos[0] + (i == 0 || i == 2 ? 14 : i == 1 ? 0 : 28);
            int y = pos[1] + (i == 0 ? 0 : i == 1 || i == 3 ? 14 : 28);
            context.fill(x, y, x + 12, y + 12, down[i] ? VividClient.accentColor : 0xAA18151F);
            context.drawCenteredTextWithShadow(client.textRenderer, keys[i], x + 6, y + 2, 0xFFFFFFFF);
        }
        boolean attack = client.options.attackKey.isPressed();
        boolean use = client.options.useKey.isPressed();
        context.fill(pos[0], pos[1] + 43, pos[0] + 25, pos[1] + 55, attack ? VividClient.accentColor : 0xAA18151F);
        context.fill(pos[0] + 28, pos[1] + 43, pos[0] + 53, pos[1] + 55, use ? VividClient.accentColor : 0xAA18151F);
        context.drawCenteredTextWithShadow(client.textRenderer, "LMB", pos[0] + 12, pos[1] + 45, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(client.textRenderer, "RMB", pos[0] + 40, pos[1] + 45, 0xFFFFFFFF);
    }

    private static void renderArmor(DrawContext context, MinecraftClient client) {
        int x = 8;
        int y = client.getWindow().getScaledHeight() - 28;
        for (var stack : client.player.getArmorItems()) {
            if (!stack.isEmpty()) {
                int durability = stack.getMaxDamage() <= 0 ? 100 : (int) (100.0 * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage());
                text(context, durability + "%", x, y, durability < 25 ? 0xFFFF5555 : 0xFFFFFFFF);
                x += 35;
            }
        }
    }

    private static void renderTarget(DrawContext context, MinecraftClient client) {
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity entity = hit.getEntity();
        if (!(entity instanceof LivingEntity living)) return;
        String label = entity.getName().getString() + "  " + String.format("%.1f HP", living.getHealth());
        text(context, label, client.getWindow().getScaledWidth() / 2 + 12,
                client.getWindow().getScaledHeight() / 2 + 8, 0xFFFFFFFF);
    }

    private static void renderCrosshair(DrawContext context, MinecraftClient client) {
        int centerX = client.getWindow().getScaledWidth() / 2;
        int centerY = client.getWindow().getScaledHeight() / 2;
        int color = VividClient.accentColor;
        context.fill(centerX - 5, centerY, centerX - 2, centerY + 1, color);
        context.fill(centerX + 2, centerY, centerX + 5, centerY + 1, color);
        context.fill(centerX, centerY - 5, centerX + 1, centerY - 2, color);
        context.fill(centerX, centerY + 2, centerX + 1, centerY + 5, color);
    }

    private static void renderPotions(DrawContext context, MinecraftClient client) {
        int x = client.getWindow().getScaledWidth() - 150;
        int y = 8;
        for (StatusEffectInstance effect : client.player.getStatusEffects()) {
            int seconds = Math.max(0, effect.getDuration() / 20);
            String duration = String.format("%d:%02d", seconds / 60, seconds % 60);
            String name = effect.getEffectType().value().getName().getString();
            String amplifier = effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : "";
            text(context, name + amplifier + "  " + duration, x, y, 0xFFFFFFFF);
            y += 14;
        }
    }

    private static void renderDamageTint(DrawContext context, MinecraftClient client) {
        int alpha = Math.min(90, client.player.hurtTime * 6);
        int color = (alpha << 24) | 0x00FF2020;
        context.fill(0, 0, client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight(), color);
    }

    private static void sampleClicks(MinecraftClient client) {
        long now = System.currentTimeMillis();
        boolean left = client.options.attackKey.isPressed();
        boolean right = client.options.useKey.isPressed();
        if (left && !wasLeftDown) leftClicks++;
        if (right && !wasRightDown) rightClicks++;
        wasLeftDown = left;
        wasRightDown = right;
        if (now - clickWindow >= 1000) {
            leftClicks = 0;
            rightClicks = 0;
            clickWindow = now;
        }
    }
}